<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Defect extends Model { protected $guarded=[]; protected $casts=['history'=>'array']; public function reporter(){return $this->belongsTo(User::class,'reporter_id');} public function assignee(){return $this->belongsTo(User::class,'assignee_id');} public function floor(){return $this->belongsTo(Floor::class);} }
