<?php
namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Database\UniqueConstraintViolationException;

class RegistrationController
{
    public function show()
    {
        return view('register');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:100'],
            'email' => ['required', 'email', 'max:255', 'unique:users,email'],
            'password' => ['required', 'string', 'min:12', 'max:72', 'confirmed'],
        ]);

        try {
            $user = User::create([
                'name' => $data['name'],
                'email' => $data['email'],
                'password' => Hash::make($data['password']),
                'role' => 'staff',
            ]);
        } catch (UniqueConstraintViolationException $exception) {
            return back()->withErrors(['email' => 'This email is already registered.'])->withInput($request->only('name', 'email'));
        }

        Auth::login($user);
        $request->session()->regenerate();
        return redirect('/')->with('success', 'Your account has been created. Welcome to HDMS!');
    }
}
