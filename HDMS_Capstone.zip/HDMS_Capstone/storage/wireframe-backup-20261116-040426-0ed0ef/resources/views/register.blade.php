<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>HDMS • Create account</title><link rel="stylesheet" href="{{ asset('style.css') }}">
<link rel="stylesheet" href="{{ asset('capstone.css') }}"></head>
<body><div class="login">
<div class="hero"><div class="brand"><span>◈</span> HDMS<small>CAPSTONE EDITION</small></div>
<h1 style="font-size:42px">Better facilities.<br>Start with you.</h1><p>Report defects, follow maintenance progress and help keep your workplace operating smoothly.</p>
<div style="margin-top:24px;color:#c0d7cc;line-height:2">01 &nbsp; Report facility defects<br>02 &nbsp; Track repair progress<br>03 &nbsp; Verify completed work</div></div>
<div class="signin"><form class="panel" method="POST" action="{{ route('register.store') }}">@csrf
<h1>Create an account</h1><p>Join your facility operations workspace.</p>
<div class="alert" style="background:#dff2e9;color:#09695d">Account type: <strong>Hospital Staff</strong><br><small style="color:#09695d">Contact your administrator for maintenance or admin access.</small></div>
@foreach($errors->all() as $error)<div class="alert error" role="alert">{{ $error }}</div>@endforeach
<label for="name">Full name</label><input id="name" style="width:100%" name="name" value="{{ old('name') }}" required maxlength="100" autocomplete="name" autofocus placeholder="Enter your full name">
<label for="email">Email address</label><input id="email" style="width:100%" type="email" name="email" value="{{ old('email') }}" required maxlength="255" autocomplete="email" placeholder="you@example.com">
<label for="password">Password</label><input id="password" style="width:100%" type="password" name="password" required minlength="12" maxlength="72" autocomplete="new-password" placeholder="At least 12 characters">
<label for="password_confirmation">Confirm password</label><input id="password_confirmation" style="width:100%" type="password" name="password_confirmation" required minlength="12" maxlength="72" autocomplete="new-password" placeholder="Re-enter your password">
<label style="font-weight:400"><input type="checkbox" id="show-password"> Show passwords</label>
<button style="width:100%;margin-top:15px" type="submit">Create account →</button>
<p style="text-align:center;margin-top:20px">Already registered? <a href="{{ route('login') }}" style="font-weight:700">Sign in</a></p>
</form></div></div>
<script>document.getElementById('show-password').addEventListener('change',function(){for(const id of ['password','password_confirmation'])document.getElementById(id).type=this.checked?'text':'password';});</script>
</body></html>
