<div class="full" id="hdms-report-map" style="margin-top:12px">
    <label>Pin defect location on floorplan</label>
    <p id="hdms-report-map-message" aria-live="polite"></p>
    <div id="hdms-report-plan" class="floor" style="cursor:crosshair;display:none;border:0;line-height:0">
        <img id="hdms-report-image" alt="Selected floorplan" draggable="false">
        <span id="hdms-report-pin" class="pin" style="display:none;pointer-events:none">!</span>
    </div>
    <input type="hidden" name="x"><input type="hidden" name="y"><input type="hidden" name="plan_version">
    <div id="hdms-report-plans" hidden>
        <?php $__currentLoopData = $floors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($f->image): ?>
                <span data-floor="<?php echo e($f->id); ?>" data-src="<?php echo e(asset('storage/'.$f->image)); ?>" data-version="<?php echo e(hash('sha256',$f->image)); ?>"></span>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\HDMS_Capstone\resources\views/report-map.blade.php ENDPATH**/ ?>