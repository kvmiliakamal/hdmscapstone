<?php
return ['categories'=>['Civil & Structural','Electrical','Mechanical','Plumbing & Sanitary','ACMV','Fire Protection','Architectural','Other']];
