<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HdmsController as H;
use App\Http\Controllers\RegistrationController;
Route::middleware('guest')->group(function () {
    Route::get('/register', [RegistrationController::class, 'show'])->name('register');
    Route::post('/register', [RegistrationController::class, 'store'])->middleware('throttle:5,1')->name('register.store');
});
Route::get('/login',[H::class,'loginPage'])->name('login');Route::post('/login',[H::class,'login'])->middleware('throttle:10,1');
Route::middleware('auth')->group(function(){
    Route::post('/logout',[H::class,'logout']);
    Route::get('/',[H::class,'index']);
    Route::post('/defects',[H::class,'create']);
    Route::post('/defects/{defect}',[H::class,'update']);
    Route::post('/defects/{defect}/map',[H::class,'map']);
    Route::post('/floors',[H::class,'floor']);
    Route::post('/floors/{floor}/image',[H::class,'upload']);
    Route::post('/users',[H::class,'user']);
    Route::get('/export',[H::class,'export']);
    Route::get('/evidence/{defect}/{kind}',[H::class,'evidence']);

    });
