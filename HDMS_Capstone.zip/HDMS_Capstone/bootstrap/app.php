<?php
return Illuminate\Foundation\Application::configure(basePath: dirname(__DIR__))->withRouting(web: __DIR__.'/../routes/web.php')->withMiddleware(function (Illuminate\Foundation\Configuration\Middleware $middleware) { $middleware->redirectGuestsTo('/login'); })->withExceptions(function (Illuminate\Foundation\Configuration\Exceptions $exceptions) {})->create();
