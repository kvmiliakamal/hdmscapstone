<?php
if(PHP_SAPI!=='cli')exit(1);
$root=dirname(__DIR__);$manifest=json_decode(file_get_contents(__DIR__.'/manifest.json'),true,512,JSON_THROW_ON_ERROR);
if(!is_file($root.'/artisan')||!is_file($root.'/public/capstone.css')||!is_file($root.'/public/auto-map.js')){fwrite(STDERR,"Extract into the existing HDMS_Capstone project, not the internship project.\n");exit(1);}
$changed=[];$custom=[];
foreach($manifest as $file=>$old){$target=$root.'/'.$file;$source=__DIR__.'/payload/'.$file;if(!is_file($source)||($old!==null&&!is_file($target))){fwrite(STDERR,"Missing file: $file\n");exit(1);}if(is_file($target)&&hash_file('sha256',$source)===hash_file('sha256',$target))continue;if(is_file($target)&&hash_file('sha256',$target)!==$old)$custom[]=$file;$changed[]=$file;}
if(!$changed){echo "Wireframe update already installed.\n";exit;}
if($custom&&!in_array('--allow-custom',$argv,true)){echo "Locally modified files detected:\n - ".implode("\n - ",$custom)."\nNo files changed. Review these files first. To replace them after making a backup, rerun with --allow-custom.\n";exit(2);}
$backup=$root.'/storage/wireframe-backup-'.date('Ymd-His').'-'.bin2hex(random_bytes(3));
$done=[];
try{foreach($changed as $file){$target=$root.'/'.$file;if(is_file($target)){$dest=$backup.'/'.$file;if(!is_dir(dirname($dest))&&!mkdir(dirname($dest),0775,true))throw new RuntimeException('Cannot create backup');if(!copy($target,$dest))throw new RuntimeException('Cannot back up '.$file);}}foreach($changed as $file){$target=$root.'/'.$file;$done[]=$file;if(!copy(__DIR__.'/payload/'.$file,$target))throw new RuntimeException('Cannot update '.$file);}echo "DefectIQ wireframe interface installed.\nBackup: $backup\nRun php artisan optimize:clear and refresh with Ctrl+F5.\n";}catch(Throwable $e){foreach(array_reverse($done) as $file){$target=$root.'/'.$file;if(is_file($backup.'/'.$file))copy($backup.'/'.$file,$target);elseif(is_file($target))unlink($target);}fwrite(STDERR,$e->getMessage()."; rollback attempted. Check backup: $backup\n");exit(1);}
