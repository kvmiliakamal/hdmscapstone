# HDMS — Capstone Edition
Laravel 12 / PHP 8.2+ / MySQL or XAMPP MariaDB. Standalone project, not a patch for another Laravel project. No Node.js or npm required. Internet access required for Composer installation. PHP syntax checked; full framework/database/browser tests have not been run in the authoring environment.

## Windows / XAMPP setup
1. Install XAMPP with PHP 8.2 or newer and Composer for Windows. During Composer installation choose `C:\xampp\php\php.exe`. Open a new Command Prompt; run `php -v` and `composer -V`. If PHP is not recognized, add `C:\xampp\php` to PATH. Enable required extensions in `C:\xampp\php\php.ini` (pdo_mysql, mbstring, openssl, fileinfo, curl, zip); restart terminal and Apache if edited.
2. Extract the ZIP so `C:\xampp\htdocs\HDMS_Capstone\artisan` exists. Start Apache and MySQL in XAMPP. Apache is for phpMyAdmin; the application uses Artisan's server.
3. Open http://localhost/phpmyadmin and create an empty database named `hdms_capstone` with utf8mb4_unicode_ci collation. Do not import a SQL file; migrations create tables. If MySQL uses a different port or credentials, adjust `.env` below.
4. In Command Prompt:
   ```bat
   cd /d C:\xampp\htdocs\HDMS_Capstone
   composer install
   copy .env.example .env
   php artisan key:generate
   ```
5. Open `.env` in VS Code. Check DB_CONNECTION=mysql, DB_HOST=127.0.0.1, DB_PORT=3306, DB_DATABASE=hdms_capstone, DB_USERNAME=root, DB_PASSWORD= (blank only for default local XAMPP). Save.
6. Run:
   ```bat
   php artisan config:clear
   php artisan migrate --seed
   php artisan storage:link
   php artisan serve --port=8001
   ```
7. Open http://127.0.0.1:8001. Keep the terminal running. Ctrl+C stops it. If port 8001 is occupied use `php artisan serve --port=8002` and open that port. Update APP_URL accordingly.

## Demo accounts
All four demo accounts use `CapstoneDemo2026!`.
- admin@capstone.test — Admin
- staff@capstone.test — Hospital Staff
- maintenance@capstone.test — Maintenance Staff (Amir)
- farah@capstone.test — Maintenance Staff (Farah)

## Demonstration
Sign in as staff, report defect with optional photo. Sign out, log in as admin, open Defect register, View, choose Amir and save (Open becomes Assigned). Add due date if needed. In Floorplan select a floor and upload your plan. Staff reporting on a floor with an uploaded plan must click its location before submitting. Admin can map older reports. The visible map refreshes every five seconds. Login as Amir, open Work orders, update to In Progress, then Resolved with a repair image. Login as reporting staff and select Verified or Open (reopen). Admin can export CSV and create users. Resolved/verified items disappear from active heatmap. Default sample plans are illustrative; replacement clears coordinates for that floor, so remap them. Photos are private and served through authenticated routes; floorplans use the public storage link.

## Troubleshooting
- `Could not open input file: artisan`: wrong folder; run `dir` and locate artisan.
- `vendor/autoload.php` missing: run composer install, resolve all Composer errors first.
- `could not find driver`: enable extension=pdo_mysql in CLI php.ini (`php --ini`).
- `SQLSTATE[HY000] [1049] Unknown database`: create hdms_capstone in phpMyAdmin.
- `Connection refused`: start MySQL and check actual port; `Access denied`: check credentials.
- Floorplan image missing: run `php artisan storage:link`, check public/storage and storage/app/public/floorplans. If Windows denies symlink creation, enable Developer Mode or use an elevated terminal; do not delete uploaded files. Check PHP upload_max_filesize and post_max_size (e.g. 8M and 10M).
- `No application encryption key`: copy .env.example and generate key.
- Do not run migrate:fresh on a database containing real reports; it deletes tables.

## Limitations / deployment
This is a local demonstration build, not a certified production hospital application. Heatmap is a priority-weighted CSS radial overlay, not calibrated kernel-density analysis. Floorplans are public through the storage URL; use nonsensitive sample plans only until private floorplan delivery is implemented. Default accounts and seed records are for testing only; remove/replace all demo credentials and records before real deployment. No password reset/change screen, email notifications, QR codes, SLA alerts or enterprise auditing. Before deployment add secure account lifecycle, private floorplan access, HTTPS, backups, logging, security review and integration/browser tests. Set APP_DEBUG=false in production and never expose .env or the project root; web root must be public/. Do not upload patient data.

## Separate capstone edition
This package merges the original project, signup, automatic map and collapsible preview patches, with a forest/teal visual redesign and a shared category configuration in config/hdms.php. It does not copy any records or local changes from your existing laptop. Create a NEW database named hdms_capstone and never point this edition at your internship database. Separate port 8001 and session cookie allow simultaneous local use. Demo accounts only; Tinker is declared as a dependency. Do not copy your old .env or storage folder.
