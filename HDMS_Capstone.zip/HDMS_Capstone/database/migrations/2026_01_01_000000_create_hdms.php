<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {public function up():void {
Schema::create('users',function(Blueprint $t){$t->id();$t->string('name');$t->string('email')->unique();$t->string('password');$t->string('role');$t->rememberToken();$t->timestamps();});
Schema::create('floors',function(Blueprint $t){$t->id();$t->string('name')->unique();$t->string('image')->nullable();$t->timestamps();});
Schema::create('defects',function(Blueprint $t){$t->id();$t->string('title');$t->string('category');$t->string('priority');$t->string('status')->default('Open');$t->foreignId('floor_id')->constrained();$t->string('location');$t->text('description');$t->foreignId('reporter_id')->constrained('users');$t->foreignId('assignee_id')->nullable()->constrained('users');$t->string('photo')->nullable();$t->string('proof')->nullable();$t->date('due')->nullable();$t->decimal('x',8,5)->nullable();$t->decimal('y',8,5)->nullable();$t->json('history');$t->timestamps();});
}public function down():void{Schema::dropIfExists('defects');Schema::dropIfExists('floors');Schema::dropIfExists('users');}};
