(()=>{
 const box=document.getElementById('hdms-report-map');
 if(box){
  const form=box.closest('form'), floor=form.elements.floor_id, x=form.elements.x,y=form.elements.y, version=form.elements.plan_version;
  const plan=box.querySelector('#hdms-report-plan'), img=box.querySelector('#hdms-report-image'), pin=box.querySelector('#hdms-report-pin'), msg=box.querySelector('#hdms-report-map-message');
  let selected=null, ready=false;
  function change(){
   selected=[...box.querySelectorAll('[data-floor]')].find(el=>el.dataset.floor===floor.value); ready=false; x.value=y.value=version.value=''; pin.style.display='none'; plan.style.display='none';
   if(!selected){img.removeAttribute('src');msg.textContent='No floorplan uploaded. You can submit this report, but it will remain unmapped until an Admin maps it.';return;}
   version.value=selected.dataset.version;msg.textContent='Loading floorplan…';img.src=selected.dataset.src;
   if(img.complete&&img.naturalWidth) loaded();
  }
  function loaded(){if(!selected)return;ready=true;plan.style.display='block';msg.textContent='Click the exact defect location on the floorplan.';}
  img.addEventListener('load',loaded);img.addEventListener('error',()=>{if(selected){ready=false;plan.style.display='none';msg.textContent='Floorplan failed to load. Contact Admin or check the storage link.';}});
  floor.addEventListener('change',change);
  img.addEventListener('click',e=>{if(!ready)return;const r=img.getBoundingClientRect();x.value=Math.max(0,Math.min(100,(e.clientX-r.left)/r.width*100)).toFixed(5);y.value=Math.max(0,Math.min(100,(e.clientY-r.top)/r.height*100)).toFixed(5);pin.style.left=x.value+'%';pin.style.top=y.value+'%';pin.style.display='block';msg.textContent='Location selected. It will be mapped automatically when submitted.';});
  form.addEventListener('submit',e=>{if(selected&&(!ready||x.value===''||y.value==='')){e.preventDefault();msg.textContent='Please select the exact defect location on the floorplan before submitting.';box.scrollIntoView({block:'center'});}});
  change();
 }
 const map=document.getElementById('floorMap');
 if(!map)return;
 const marker=document.getElementById('hdms-live-map'); if(!marker)return;
 let busy=false;
 async function refresh(){
  if(busy||document.hidden||document.querySelector('dialog[open]')||document.getElementById('mapDefect')?.value)return;
  busy=true;
  try{
   const url=new URL(location.href);url.searchParams.set('map_live','1');url.searchParams.set('floor',marker.dataset.floor);url.searchParams.delete('detail');
   const res=await fetch(url,{headers:{Accept:'application/json'},cache:'no-store'});if(!res.ok)throw Error('Refresh failed');const data=await res.json();
   if(String(data.floor)!==marker.dataset.floor)return;
   if(data.imageVersion!==marker.dataset.version){marker.textContent='Floorplan changed. Refresh this page to load the new layout.';return;}
   const hidden=map.querySelector('.heat')?.hidden??map.dataset.heatHidden==='true';
   map.querySelectorAll('.heat,.pin').forEach(el=>el.remove());
   for(const d of data.defects){
    if(d.x===null||d.y===null)continue;
    const heat=document.createElement('div');heat.className='heat';heat.style.left=d.x+'%';heat.style.top=d.y+'%';heat.style.opacity=({Critical:1,High:.85,Medium:.65,Low:.4}[d.priority]??.5);heat.hidden=hidden;map.append(heat);
    const pin=document.createElement('a');pin.className='pin';pin.title=d.title;pin.textContent='!';pin.style.left=d.x+'%';pin.style.top=d.y+'%';const href=new URL(location.href);href.searchParams.delete('map_live');href.searchParams.set('floor',data.floor);href.searchParams.set('detail',d.id);pin.href=href.toString();map.append(pin);
   }
   const picker=document.getElementById('mapDefect');if(picker&&!picker.value){picker.replaceChildren(new Option('Select defect',''));for(const d of data.defects)picker.add(new Option('DF-'+d.id+' — '+d.title,d.id));}
   marker.textContent=data.defects.filter(d=>d.x!==null&&d.y!==null).length+' active mapped · '+data.defects.filter(d=>d.x===null||d.y===null).length+' unmapped · Live updated';
  }catch(e){marker.textContent='Live refresh unavailable. Retrying…';}finally{busy=false;}
 }
 setInterval(refresh,5000);
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)refresh();});
})();
