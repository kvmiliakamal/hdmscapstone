(()=>{
const shell=document.querySelector('.shell'),side=shell?.querySelector(':scope > aside'),header=shell?.querySelector(':scope > main > header');
if(!side||!header||shell.classList.contains('hdms-sidebar-ready'))return;
const mobile=window.matchMedia('(max-width:850px)');let collapsed=false,open=false;
try{collapsed=localStorage.getItem('hdms.capstone.sidebar.collapsed')==='1'}catch(e){}
side.id=side.id||'hdms-sidebar';
side.querySelectorAll('a.nav').forEach(a=>{const text=a.textContent.trim();const [icon,...rest]=text.split(/\s+/);if(!rest.length)return;const label=rest.join(' ');const i=document.createElement('span'),l=document.createElement('span');i.className='hdms-nav-icon';i.textContent=icon;i.setAttribute('aria-hidden','true');l.className='hdms-nav-label';l.textContent=label;a.replaceChildren(i,l);a.title=label;a.setAttribute('aria-label',label)});
const start=document.createElement('div');start.className='hdms-header-start';const toggle=document.createElement('button');toggle.type='button';toggle.className='hdms-sidebar-toggle';toggle.textContent='☰';toggle.setAttribute('aria-controls',side.id);const original=header.firstElementChild;header.prepend(start);start.append(toggle);if(original)start.append(original);
const backdrop=document.createElement('button');backdrop.type='button';backdrop.className='hdms-sidebar-backdrop';backdrop.hidden=true;backdrop.tabIndex=-1;backdrop.setAttribute('aria-label','Close navigation');shell.append(backdrop);
function render(){const m=mobile.matches;shell.classList.toggle('hdms-collapsed',!m&&collapsed);shell.classList.toggle('hdms-mobile-open',m&&open);backdrop.hidden=!(m&&open);const expanded=m?open:!collapsed;toggle.setAttribute('aria-expanded',String(expanded));toggle.setAttribute('aria-label',expanded?'Collapse navigation':'Expand navigation');toggle.title=expanded?'Collapse navigation':'Expand navigation';if(m&&!open)side.setAttribute('inert','');else side.removeAttribute('inert')}
function close(){open=false;render();toggle.focus()}
toggle.addEventListener('click',()=>{if(mobile.matches)open=!open;else{collapsed=!collapsed;try{localStorage.setItem('hdms.capstone.sidebar.collapsed',collapsed?'1':'0')}catch(e){}}render()});backdrop.addEventListener('click',close);document.addEventListener('keydown',e=>{if(e.key==='Escape'&&open)close()});mobile.addEventListener('change',()=>{open=false;render()});shell.classList.add('hdms-sidebar-ready');render();
})();
